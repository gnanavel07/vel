package myproject;

public class Myfirstclass {
	
	public void myMethod() {
		   System.out.println("this is my method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("this is mymethod");
		Myfirstclass m= new Myfirstclass();
		m.myMethod();
	
	
	}

}
